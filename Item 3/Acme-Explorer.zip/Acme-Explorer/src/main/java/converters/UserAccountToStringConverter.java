package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import security.UserAccount;

@Component
@Transactional
public class UserAccountToStringConverter implements Converter<UserAccount, String>{
	
	@Override
	public String convert(final UserAccount usserAccount) {
		String result;

		if (usserAccount == null)
			result = null;
		else
			result = String.valueOf(usserAccount.getId());

		return result;
	}

}
